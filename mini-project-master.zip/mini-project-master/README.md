# BootstrapDylut

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8
And it using [Material Design for Bootstrap](https://mdbootstrap.com/docs/angular/)

## How it works

clone or download the project <br>
switch to the project directory <br>
Run the following command

```bash
# To remove my git files and make the template yours
$ rm -rf .git

# Install all the dependencies
$ sudo npm install

# Then run the project
$ ng serve -o
```

This project was created by [Hardy Lutula #dylut2000](https://twitter.com/dylut2000?lang=en)


Have fun guys... will add some more stuff so stay tune on my [GITHUB dylut2000](https://github.com/dylut2000)
